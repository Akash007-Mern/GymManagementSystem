﻿using GymManagementSystem.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace GymManagementSystem.Data
{
    // Changed from DbContext to IdentityDbContext to support login system
    public class GymManagementDB : IdentityDbContext<ApplicationUser>
    {
        public GymManagementDB(DbContextOptions<GymManagementDB> options)
            : base(options)
        {
        }

        // Our gym tables
        public DbSet<Member> Members { get; set; }
        public DbSet<Trainer> Trainers { get; set; }
        public DbSet<MembershipPlan> MembershipPlans { get; set; }
        public DbSet<Payment> Payments { get; set; }
        public DbSet<Attendance> Attendances { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // This is REQUIRED for Identity to work
            base.OnModelCreating(modelBuilder);
        }
    }
}